import React, { useState } from 'react';
import confetti from 'canvas-confetti';

const App = () => {
  const [username, setUsername] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [voteReceived, setVoteReceived] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleVerify = async () => {
    const cleanUsername = username.trim();
    if (!cleanUsername) {
      setMessage('Please enter your Roblox username.');
      return;
    }

    setIsLoading(true);
    setMessage('');

    try {
      const response = await fetch('/api/roblox/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: cleanUsername })
      });

      if (!response.ok) {
        throw new Error('Verification service is unavailable or the username is invalid.');
      }

      setIsVerified(true);
      setMessage('');
    } catch (error) {
      setIsVerified(false);
      setMessage(error.message || 'Unable to verify username. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVote = () => {
    if (!isVerified) {
      setMessage('Please verify your Roblox username before voting.');
      return;
    }

    // Demo interaction only. A real election must record votes securely on a backend.
    setVoteReceived(true);
    setMessage('');
    confetti({ particleCount: 110, spread: 65, origin: { y: 0.7 } });
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="./" aria-label="VotePulse home">
          <span className="brand-mark">V</span>
          <span>VotePulse</span>
        </a>
        <span className="topbar-tag">MALAYSIA ELECTION</span>
      </header>

      <main className="main-content">
        <section className="welcome">
          <div className="eyebrow">OFFICIAL ELECTION BALLOT PORTAL</div>
          <h1>Your voice.<br /><span>Your choice.</span></h1>
          <p>Welcome to the VotePulse voter portal. Verify your Roblox account to continue.</p>
        </section>

        <section className="voter-card">
          <div className="card-heading">
            <div>
              <div className="step-label">VOTER ACCESS</div>
              <h2>Voter verification</h2>
            </div>
            <div className={`status-dot ${isVerified ? 'verified' : ''}`} title={isVerified ? 'Verified' : 'Not verified'} />
          </div>

          <label htmlFor="roblox-username">Roblox username</label>
          <input
            id="roblox-username"
            value={username}
            onChange={(event) => {
              setUsername(event.target.value);
              setIsVerified(false);
              setVoteReceived(false);
              setMessage('');
            }}
            placeholder="Enter your Roblox username"
            autoComplete="off"
          />

          <button className="button button-secondary" onClick={handleVerify} disabled={isLoading}>
            {isLoading ? 'Verifying…' : 'Verify username'}
          </button>

          {isVerified && (
            <div className="verified-message">
              <span className="checkmark">✓</span>
              Verified user: <strong>@{username.trim()}</strong>
            </div>
          )}

          {message && <p className="message" role="alert">{message}</p>}

          <div className="card-divider" />

          <div className="vote-row">
            <div>
              <h3>Ready to vote?</h3>
              <p>Complete account verification before submitting.</p>
            </div>
            <button className="button button-primary" onClick={handleVote} disabled={!isVerified || voteReceived}>
              {voteReceived ? 'Vote submitted' : 'Submit vote'}
            </button>
          </div>

          {voteReceived && (
            <div className="success-message" role="status">
              <strong>Your vote has been submitted!</strong>
              <span>This is a frontend demonstration. No official vote has been recorded.</span>
            </div>
          )}
        </section>

        <p className="security-note">Your account details should only be processed by the official election verification service.</p>
      </main>

      <footer className="footer">
        <span>VotePulse · Malaysia Election</span>
        <span>© Lembaga Pilihan Raya MLYSA 2026</span>
      </footer>
    </div>
  );
};

export default App;