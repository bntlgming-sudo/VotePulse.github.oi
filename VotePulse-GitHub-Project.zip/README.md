# VotePulse

A React + Vite frontend prepared for GitHub Pages.

## Publish using GitHub

1. Create a **public** GitHub repository named `votepulse`.
2. Upload the contents of this folder to the repository (keep the `.github/workflows/deploy.yml` path).
3. Open **Settings → Pages** and set the build/deployment source to **GitHub Actions**.
4. Push/commit the files to the `main` branch.
5. Open the **Actions** tab and wait for “Deploy VotePulse to GitHub Pages” to finish.
6. Your site will be available at `https://YOUR-USERNAME.github.io/votepulse/`.

## Important backend note

The original code calls `POST /api/roblox/verify`. GitHub Pages is static hosting and does not run API routes. Connect this frontend to a separately hosted backend and change the fetch URL in `src/App.jsx` to that backend's HTTPS endpoint.

The “Submit vote” interaction is currently a frontend demonstration only. It does not securely record an election vote. A real election requires a trusted backend, server-side identity verification, secure vote storage, and duplicate-vote prevention.

## Run locally

```bash
npm install
npm run dev
```
